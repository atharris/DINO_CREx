var searchData=
[
  ['plotfunction',['plotFunction',['../namespaceplot_filter.html#acf4decf406d799ce3fcbe20a0d642c60',1,'plotFilter.plotFunction()'],['../namespaceplot_integrated_filter.html#a82cc728093755667ae8f8e9c9bce639b',1,'plotIntegratedFilter.plotFunction()']]]
];
