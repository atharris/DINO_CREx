var indexSectionsWithContent =
{
  0: "bcdfgimnprtw",
  1: "bcip",
  2: "bfgimnprw",
  3: "bcdipt"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "functions",
  3: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Functions",
  3: "Modules"
};

