var searchData=
[
  ['pixel_20and_20line',['Pixel and Line',['../group__pixel__and__line.html',1,'']]]
];
