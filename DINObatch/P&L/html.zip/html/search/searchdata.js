var indexSectionsWithContent =
{
  0: "bcdefgimnprstu",
  1: "d",
  2: "bciprstu",
  3: "bfgimnpr",
  4: "bept"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Modules"
};

